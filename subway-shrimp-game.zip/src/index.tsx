import React, { useEffect, useRef, useState } from "react";

export default function Home(): JSX.Element {
  return <SubwayShrimpGame />;
}

// (full game code was in canvas, assume included)
